#!/usr/bin/python
# -*- coding: utf-8 -*-
from flask import Flask , request , redirect
import re , json , urllib
import requests , YDStreamExtractor
from operator import itemgetter
requests . packages . urllib3 . disable_warnings ( )
YDStreamExtractor . disableDASHVideo ( True )
if 64 - 64: i11iIiiIii
app = Flask ( __name__ )
if 81 - 81: Iii1I1 + OO0O0O % iiiii % ii1I - ooO0OO000o
@ app . route ( '/play' )
def ii11i ( ) :
 return oOooOoO0Oo0O ( )
 if 10 - 10: IIiI1I11i11
@ app . route ( '/play.m3u8' )
def oOooOoO0Oo0O ( ) :
 real_urlpath = ""
 try :
  real_urlpath = request . args . get ( "url" )
 except : return ""
 if "livestream.com" in real_urlpath :
  useragent_codes = {
 'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0' ,
 'Accept-Encoding' : 'gzip, deflate' ,
 }
  try :
   if "events" not in real_urlpath :
    url_requests = requests . get ( real_urlpath , headers = useragent_codes )
    url_contents = re . search ( "accounts/\d+/events/\d+" , url_requests . text )
    real_urlpath = "https://livestream.com/api/%s" % url_contents . group ( )
   url_requests = requests . get ( real_urlpath , headers = useragent_codes )
   url_links = url_requests . json ( )
   real_urlpath = url_links [ "stream_info" ] [ "m3u8_url" ]
  except : pass
 elif "talktv.vn" in real_urlpath :
  useragent_codes = {
 'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0' ,
 'Accept-Encoding' : 'gzip, deflate' ,
 }
  try :
   url_requests = requests . get ( real_urlpath , headers = useragent_codes )
   IiI = re . search ( 'loadPlayer.manifestUrl = "(.+?)"' , url_requests . text ) . group ( 1 )
   real_urlpath = IiI
  except : pass
 elif "ustream.tv" in real_urlpath :
  useragent_codes = {
 'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0' ,
 'Accept-Encoding' : 'gzip, deflate' ,
 }
  try :
   url_requests = requests . get ( real_urlpath , headers = useragent_codes )
   ooOo = re . search ( "tv/embed/(\d+)" , url_requests . text ) . group ( 1 )
   real_urlpath = "http://iphone-streaming.ustream.tv/uhls/%s/streams/live/iphone/playlist.m3u8" % ooOo
  except : pass
 elif "youtube.com" in real_urlpath :
  useragent_codes = {
 'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0' ,
 'Accept-Encoding' : 'gzip, deflate' ,
 }
  try :
   url_requests = requests . get ( real_urlpath , headers = useragent_codes )
   url_contents = re . search ( '"hlsvp":".+?"' , url_requests . text )
   url_links = json . loads ( '{%s}' % url_contents . group ( ) )
   real_urlpath = url_links [ "hlsvp" ]
  except :
   try :
    real_urlpath = YDStreamExtractor . getVideoInfo ( real_urlpath ) . streamURL ( )
   except : pass
 elif "vtvgo-" in real_urlpath :
  vtvgo_chid = real_urlpath . split ( "-" ) [ - 1 ]
  real_urlpath = "http://vtvgo.vn/get-program-channel-detail?epg_id=%s&id=%s&type=1" % ( vtvgo_chid , vtvgo_chid )
  useragent_codes = {
 "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36" ,
 "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8" ,
 "Accept-Encoding" : "gzip, deflate" ,
 "Referer" : "http://vtvgo.vn/" ,
 }
  if 67 - 67: O00ooOO . I1iII1iiII
  iI1Ii11111iIi = requests . get ( "aHR0cDovL3Z0dmdvLnZuL3hlbS10cnVjLXR1eWVuLmh0bWw=" . decode ( "base64" ) , headers = useragent_codes )
  i1i1II = re . compile ( "'(\w{32})'\)\;" ) . findall ( iI1Ii11111iIi . text . encode ( "utf8" ) ) [ 0 ]
  try :
   O0oo0OO0 = re . compile ( 'epg_id=(\d+)' ) . findall ( real_urlpath ) [ 0 ]
   I1i1iiI1 = re . compile ( 'type=(\d+)' ) . findall ( real_urlpath ) [ 0 ]
   useragent_codes = {
 "X-Requested-With" : "XMLHttpRequest" ,
 "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36" ,
 "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8" ,
 "Accept-Encoding" : "gzip, deflate" ,
 "Referer" : "http://vtvgo.vn/" ,
 "Cookie" : "csrf_security=1"
 }
   iiIIIII1i1iI = {
 "epg_id" : O0oo0OO0 ,
 "type" : I1i1iiI1 ,
 "secret_token" : i1i1II ,
 "csrf_security" : "1"
 }
   o0oO0 = requests . post ( real_urlpath , headers = useragent_codes , data = iiIIIII1i1iI ) . json ( )
   real_urlpath = o0oO0 [ "data" ]
  except : pass
 elif "facebook.com" in real_urlpath :
  oo00 = re . search ( "videos/(\d+)" , real_urlpath ) . group ( 1 )
  real_urlpath = "https://www.facebook.com/video/playback/playlist.m3u8?v=%s" % oo00
 elif "twitch.tv" in real_urlpath :
  try :
   o00 = "|User-Agent=Mozilla/5.0 (Windows NT 10.0; WOW64; rv:48.0) Gecko/20100101 Firefox/48.0"
   real_urlpath = YDStreamExtractor . getVideoInfo ( real_urlpath ) . streamURL ( ) . split ( "|" ) [ 0 ] + o00
  except : pass
 elif "://" not in real_urlpath :
  if real_urlpath . startswith ( "uno-" ) :
   url_token_id = real_urlpath . strip ( ) . replace ( "uno-" , "" )
   uno_params = "NTg4N2RkZmZjMzEyYmYxMDk0ZGU0YmQ1" . decode ( "base64" )
   i1 = {
 "Content-Type" : "application/x-www-form-urlencoded" ,
 "User-Agent" : "Dalvik/2.1.0" ,
 "Accept-Encoding" : "gzip"
 }
   uno_data_contruct = {
 "serial_id" : uno_params ,
 "query" : url_token_id
 }
   i1111 = requests . post (
 "http://stbapi.v247tv.com/api/stb_channel2" ,
 headers = i1 ,
 data = uno_data_contruct
 ) . json ( ) [ "data" ]
   i11 = requests . get ( "aHR0cDovL2VjaGlwc3RvcmUuY29tOjgwMDAvdW5vLw==" . decode ( "base64" ) + urllib . quote_plus ( i1111 ) )
   url_links = re . compile ( "(\{.+?\})" ) . findall ( i11 . text . strip ( ) ) [ 0 ]
   real_urlpath = json . loads ( url_links ) [ "url" ]
   if "smil:" in real_urlpath :
    I11 = re . search ( 'https*://.+?/' , real_urlpath ) . group ( )
   else :
    I11 = real_urlpath . split ( "playlist" ) [ 0 ]
   url_strips = requests . get ( real_urlpath ) . text . strip ( )
   real_urlpath = I11 + oOo0oooo00o ( url_strips )
  elif real_urlpath . startswith ( "nexttv-" ) :
   oO0o0o0ooO0oO = {
 "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36" ,
 "X-Requested-With" : "XMLHttpRequest" ,
 "Referer" : "http://tv.beeb.vn" ,
 "Accept-Encoding" : "gzip, deflate, sdch"
 }
   url_token_id = real_urlpath . strip ( ) . replace ( "nexttv-" , "" )
   iI1Ii11111iIi = requests . get (
 "http://tv.beeb.vn/site/player?channel=htv9" ,
 headers = oO0o0o0ooO0oO )
   oo0o0O00 = ""
   try :
    oo0o0O00 = re . search ( "atob\('(.+?)'\)" , iI1Ii11111iIi . text ) . group ( 1 ) . decode ( "base64" )
   except :
    try :
     oo0o0O00 = urllib . unquote_plus ( re . search ( "decodeURIComponent\('(.+?)'\)" , iI1Ii11111iIi . text ) . group ( 1 ) )
    except :
     try :
      url_contents = re . search ( "stream=_(\d+) \+ _(\d+)" , iI1Ii11111iIi . text )
      oO = url_contents . group ( 1 )
      i1iiIIiiI111 = url_contents . group ( 2 )
      oO = re . search ( '%s="(.+?)"' % oO , iI1Ii11111iIi . text ) . group ( 1 )
      i1iiIIiiI111 = re . search ( '%s="(.+?)"' % i1iiIIiiI111 , iI1Ii11111iIi . text ) . group ( 1 )
      oo0o0O00 = oO + i1iiIIiiI111
     except : pass
   real_urlpath = oo0o0O00 if "http://" in oo0o0O00 else "http://tv.beeb.vn" + oo0o0O00
   real_urlpath = requests . head (
 real_urlpath ,
 headers = oO0o0o0ooO0oO ) . headers [ "location" ]
   oooOOOOO = re . search ( 'VOD_RequestID=(.+?)($|&)' , real_urlpath ) . group ( 1 )
   real_urlpath = "http://27.67.80.6:18080/%s.m3u8?AdaptiveType=HLS&VOD_RequestID=%s" % ( url_token_id , oooOOOOO )
  else :
   i1iiIII111ii = requests . get ( "aHR0cDovL3d3dy52aWV0dHYyNC5jb20vbWFpbi9nZXRDaGFubmVsc0FwcEJveC5waHA=" . decode ( "base64" ) ) . json ( )
   for i1iIIi1 in i1iiIII111ii [ "channels" ] :
    if i1iIIi1 [ "channel_url" ] == real_urlpath :
     ii11iIi1I = "aHR0cDovL3d3dy52aWV0dHYyNC5jb20vbWFpbi9nZXRTdHJlYW1pbmdTZXJ2ZXIucGhw" . decode ( "base64" )
     i1111 = { 'strname' : '%s-' % i1iIIi1 [ "channel_id" ] }
     real_urlpath = requests . post ( ii11iIi1I , data = i1111 ) . text . strip ( )
     url_strips = requests . get ( real_urlpath ) . text . strip ( )
     I11 = re . search ( 'https*://.+?/.+?/.+?/' , real_urlpath ) . group ( )
     real_urlpath = I11 + oOo0oooo00o ( url_strips )
 else :
  try :
   real_urlpath = YDStreamExtractor . getVideoInfo ( real_urlpath ) . streamURL ( )
  except : pass
 return redirect ( real_urlpath )
 if 6 - 6: I1I11I1I1I * OooO0OO
def oOo0oooo00o ( text ) :
 url_contents = re . compile ( 'BANDWIDTH=(\d+),.+?\n(.+?)$' , re . M ) . findall ( text )
 iiiIi = [ ]
 for i1iiIIiiI111 , IiIIIiI1I1 in url_contents :
  iiiIi += [ [ int ( i1iiIIiiI111 ) , IiIIIiI1I1 ] ]
 iiiIi = sorted ( iiiIi , key = itemgetter ( 0 ) )
 return iiiIi [ - 1 ] [ - 1 ]
 if 86 - 86: i11I1IIiiIi + oOo + iiIiIiIi - o0oooO0OO0O / Oooo
if __name__ == '__main__' :
 app . run ( host = '0.0.0.0' , threaded = True ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
